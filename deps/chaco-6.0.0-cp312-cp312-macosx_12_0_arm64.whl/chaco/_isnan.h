#ifdef _WIN32
#include <float.h>
#define isnan  _isnan
#else
#include <math.h>
#endif
